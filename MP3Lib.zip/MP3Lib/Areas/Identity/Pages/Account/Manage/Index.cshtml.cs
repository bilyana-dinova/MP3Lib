﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using MP3Lib.Data;

namespace MP3Lib.Areas.Identity.Pages.Account.Manage {
    public partial class IndexModel : PageModel {
        private readonly UserManager<LoginUser> _userManager;
        private readonly SignInManager<LoginUser> _signInManager;
        private readonly ILogger<RegisterModel> _logger;

        public IndexModel (
            UserManager<LoginUser> userManager,
            SignInManager<LoginUser> signInManager,
            ILogger<RegisterModel> logger) {
            _userManager = userManager;
            _signInManager = signInManager;
            _logger = logger;
        }

        public string Username { get; set; }

        [TempData]
        public string StatusMessage { get; set; }

        [BindProperty]
        public InputModel Input { get; set; }

        public class InputModel : IValidatableObject {
            [DataType(DataType.Date)]
            [Display(Name = "Date of Birth")]
            public DateTime DateOfBirth { get; set; }

            [StringLength(100)]
            [DataType(DataType.Text)]
            [Display(Name = "First Name")]
            public string FirstName { get; set; }

            [StringLength(100)]
            [DataType(DataType.Text)]
            [Display(Name = "Last Name")]
            public string LastName { get; set; }

            public IEnumerable<ValidationResult> Validate(ValidationContext validationContext) {
                List<ValidationResult> errors = new List<ValidationResult>();
                var FromDate = DateTime.Now.AddYears(-14);
                if (DateOfBirth > FromDate) {
                    errors.Add(new ValidationResult("User age must be greater than 14 years", new List<string> { nameof(DateOfBirth) }));
                }
                return errors;
            }
        }

        private async Task LoadAsync(LoginUser user) {
            var userName = await _userManager.GetUserNameAsync(user);

            Username = userName;

            Input = new InputModel {
                FirstName = user.FirstName,
                LastName = user.LastName,
                DateOfBirth = user.DOB
            };
        }

        public async Task<IActionResult> OnGetAsync() {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }

            await LoadAsync(user);
            return Page();
        }

        public async Task<IActionResult> OnPostAsync() {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }

            if (!ModelState.IsValid) {
                await LoadAsync(user);
                return Page();
            } else {
                if (Input.DateOfBirth != user.DOB) {
                    user.DOB = Input.DateOfBirth;
                }

                if (Input.FirstName != user.FirstName) {
                    user.FirstName = Input.FirstName;
                }

                if (Input.LastName != user.LastName) {
                    user.LastName = Input.LastName;
                }

                var result = await _userManager.UpdateAsync(user);
                
                if (result.Succeeded) {
                    _logger.LogInformation("User account updated.");
                }
            }

            await _signInManager.RefreshSignInAsync(user);
            StatusMessage = "Your profile has been updated";
            return RedirectToPage();
        }
    }
}
