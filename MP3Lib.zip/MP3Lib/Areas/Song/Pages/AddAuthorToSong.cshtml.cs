using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MP3Lib.Data;

namespace MP3Lib.Areas.Author.Pages {
    public class AddAuthorToSongModel : PageModel {
        private readonly ApplicationDbContext _context;

        public AddAuthorToSongModel(ApplicationDbContext context) {
            _context = context;
        }

        public PaginatedList<Data.Author> Authors { get; set; }
        public Data.Song Song;

        public async Task<ActionResult> OnGetAsync(int? pageIndex, int? SongID) {
            if (SongID == null) {
                return NotFound();
            }

            Song = await _context.Songs.FirstOrDefaultAsync(m => m.SongID == SongID);

            if (Song == null) {
                return NotFound();
            }

            int pageSize = 20;
            IQueryable<Data.Author> AuthorIQ = _context.Authors.Select(s => s);
            Authors = await PaginatedList<Data.Author>.CreateAsync(AuthorIQ, pageIndex ?? 1, pageSize);
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? AuthorID, int? SongID) {
            if (!ModelState.IsValid) {
                return Page();
            }
            
            Song = await _context.Songs.FirstOrDefaultAsync(m => m.SongID == SongID);
            var Author = await _context.Authors.FirstOrDefaultAsync(m => m.AuthorId == AuthorID);
            AuthorSongs AS = _context.AuthorSongs.Where(As => As.SongID == SongID && As.AuthorId == AuthorID).Select(s => s).FirstOrDefault();
            if (AS == null) {
                _context.AuthorSongs.Add(new Data.AuthorSongs() { AuthorId = (int)AuthorID, SongID = Song.SongID, Autor = Author, Song = Song });
                await _context.SaveChangesAsync();
            }
            
            return RedirectToPage("./Edit", "AddAuthor", new { Id = Song.SongID });
        }
    }
}
