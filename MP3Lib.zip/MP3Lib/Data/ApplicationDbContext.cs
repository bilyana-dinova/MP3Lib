﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.IO;

namespace MP3Lib.Data {
    public class ApplicationDbContext : IdentityDbContext<LoginUser> {
        public ApplicationDbContext()
            : base() {
        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) {
        }
        
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {
            optionsBuilder.UseLazyLoadingProxies();
        }

        public DbSet<Song> Songs { get; set; }
        
        public DbSet<Author> Authors { get; set; }
        
        public DbSet<AuthorSongs> AuthorSongs { get; set; }
        
        public DbSet<PlayList> PlayLists { get; set; }

        public DbSet<PlayListSongs> PlayListSongs { get; set; }

        public DbSet<Album> Albums { get; set; }

        public DbSet<AlbumSongs> AlbumSongs { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder) {
            base.OnModelCreating(modelBuilder);

            //autors relations
            modelBuilder.Entity<AuthorSongs>()
                    .HasKey(x => new { x.AuthorId, x.SongID });

            modelBuilder.Entity<AuthorSongs>()
                .HasOne(As => As.Autor)
                .WithMany(A => A.Songs)
                .HasForeignKey(As => As.AuthorId);

            modelBuilder.Entity<AuthorSongs>()
                .HasOne(S => S.Song)
                .WithMany(As => As.Authors)
                .HasForeignKey(As => As.SongID);

            modelBuilder.Entity<PlayListSongs>()
                    .HasKey(x => new { x.PlayListId, x.SongID });

            //playlist relations
            modelBuilder.Entity<PlayListSongs>()
                .HasOne(Ps => Ps.PlayList)
                .WithMany(A => A.Songs)
                .HasForeignKey(As => As.PlayListId);

            modelBuilder.Entity<PlayListSongs>()
                .HasOne(Ps => Ps.Song)
                .WithMany(S => S.PlayListSongs)
                .HasForeignKey(As => As.SongID);

            //albums relations
            modelBuilder.Entity<AlbumSongs>()
                   .HasKey(x => new { x.AlbumId, x.SongID });

            modelBuilder.Entity<AlbumSongs>()
                .HasOne(As => As.Album)
                .WithMany(A => A.Songs)
                .HasForeignKey(A => A.AlbumId);

            modelBuilder.Entity<AlbumSongs>()
                .HasOne(AS => AS.Song)
                .WithMany(S => S.AlbumSongs)
                .HasForeignKey(As => As.SongID);

        }

    }
}
