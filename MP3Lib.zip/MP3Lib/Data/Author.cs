﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace MP3Lib.Data {
    public class Author {
        public int AuthorId { get; set; }

        [Required]
        [StringLength(50)]
        [ConcurrencyCheck]
        public string FirstName { get; set; }

        [Required]
        [StringLength(50)]
        [ConcurrencyCheck]
        public string LastName { get; set; }
        
        [StringLength(450)]
        public string Biography { get; set; }
        
        public virtual ICollection<AuthorSongs> Songs { get; set; }
    }

    public class AuthorSongs {
        public int AuthorId { get; set; }
        public virtual Author Autor { get; set; }
        public int SongID { get; set; }
        public virtual Song Song { get; set; }
    }
}
