﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MP3Lib.Data {
	public static class Roles {
		public const string ADMIN_ROLE = "Admin";
		public const string MEMBER_ROLE = "Member";
	}

	public class LoginUser : IdentityUser {
		[PersonalData]
		public string FirstName { get; set; }
		[PersonalData]
		public string LastName { get; set; }
		[PersonalData]
		public DateTime DOB { get; set; }
	}
}
