﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MP3Lib.Data {
    public class PlayList {
        [Key]
        public int PlayListId { get; set; }

        [Required]
        [StringLength(50)]
        [ConcurrencyCheck]
        public string Name { get; set; }

        [StringLength(25)]
        public string Genre { get; set; }

        [StringLength(255)]
        public string Picture { get; set; }

        public virtual ICollection<PlayListSongs> Songs { get; set; }
    }

    public class PlayListSongs {
        public int PlayListId { get; set; }
        public int SongID { get; set; }
        public virtual PlayList PlayList { get; set; }
        public virtual Song Song { get; set; }
    }
}
