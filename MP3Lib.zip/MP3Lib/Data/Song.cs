﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MP3Lib.Data {
    public class Song {
        [Key]
        public int SongID { get; set; }
        
        [Required]
        [StringLength(150)]
        [ConcurrencyCheck]
        public string SongName { get; set; }

        public DateTime CreationDate { get; set; }


        [StringLength(255)]
        public string File { get; set; }

        public virtual ICollection<AuthorSongs> Authors { get; set; }

        public virtual ICollection<PlayListSongs> PlayListSongs { get; set; }
        
        public virtual ICollection<AlbumSongs> AlbumSongs { get; set; }
    }
}
