﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MP3Lib.Data;

namespace MP3Lib.Areas.Author.Pages {
    public class IndexModel : PageModel {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context) {
            _context = context;
        }

        public PaginatedList<Data.Author> Author { get; set; }

        public async Task OnGetAsync(int? pageIndex) {
            int pageSize = 20;
            IQueryable<Data.Author> AuthorIQ = _context.Authors.Select(s => s);
            Author = await PaginatedList<Data.Author>.CreateAsync(AuthorIQ, pageIndex ?? 1, pageSize);
        }
    }
}
