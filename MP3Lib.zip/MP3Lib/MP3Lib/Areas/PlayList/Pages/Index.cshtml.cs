﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MP3Lib.Data;

namespace MP3Lib.Areas.PlayList.Pages {
    public class IndexModel : PageModel {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context) {
            _context = context;
        }

        public PaginatedList<Data.PlayList> PlayList { get; set; }

        public async Task OnGetAsync(int? pageIndex) {
            int pageSize = 20;
            IQueryable<Data.PlayList> playListsIQ = _context.PlayLists.Select(s => s);
            PlayList = await PaginatedList<Data.PlayList>.CreateAsync(playListsIQ, pageIndex ?? 1, pageSize);
        }
    }
}
