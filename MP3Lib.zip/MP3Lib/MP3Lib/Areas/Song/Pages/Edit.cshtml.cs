﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MP3Lib.Data;

namespace MP3Lib.Areas.Song.Pages {
    public class EditModel : PageModel {
        private readonly ApplicationDbContext _context;

        public EditModel(ApplicationDbContext context) {
            _context = context;
        }

        [BindProperty]
        public Data.Song Song { get; set; }

        public List<Data.Author> authors { get; set; }

        public PaginatedList<Data.AuthorSongs> AutorSongs { get; set; }


        public async Task<IActionResult> OnGetAddAuthorAsync(int? id, int? pageIndex) {
            if (id == null) {
                return NotFound();
            }

            Song = await _context.Songs.FirstOrDefaultAsync(m => m.SongID == id);

            if (Song == null) {
                return NotFound();
            }

            int pageSize = 20;
            IQueryable<Data.AuthorSongs> AutorSongsIQ = _context.AuthorSongs.Where(As => As.SongID == Song.SongID).Select(s => s);
            AutorSongs = await PaginatedList<Data.AuthorSongs>.CreateAsync(AutorSongsIQ, pageIndex ?? 1, pageSize);

            return Page();
        }

        public async Task<IActionResult> OnGetAsync(int? id, int? pageIndex) {
            if (id == null) {
                return NotFound();
            }

            Song = await _context.Songs.FirstOrDefaultAsync(m => m.SongID == id);

            if (Song == null) {
                return NotFound();
            }

            int pageSize = 20;
            IQueryable<Data.AuthorSongs> AutorSongsIQ = _context.AuthorSongs.Where(As => As.SongID == Song.SongID).Select(s => s);
            AutorSongs = await PaginatedList<Data.AuthorSongs>.CreateAsync(AutorSongsIQ, pageIndex ?? 1, pageSize);

            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync() {
            if (!ModelState.IsValid) {
                return Page();
            }

            _context.Attach(Song).State = EntityState.Modified;

            try {
                await _context.SaveChangesAsync();
            } catch (DbUpdateConcurrencyException) {
                if (!SongExists(Song.SongID)) {
                    return NotFound();
                } else {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool SongExists(int id) {
            return _context.Songs.Any(e => e.SongID == id);
        }

        public async Task<IActionResult> OnPostDeleteAsync(int? AuthorId) {
            if (!ModelState.IsValid) {
                return Page();
            }

            var AuthorSong = _context.AuthorSongs.Where(As => As.AuthorId == AuthorId && As.SongID == Song.SongID).FirstOrDefault();
            if (AuthorSong != null) {
                _context.AuthorSongs.Remove(AuthorSong);
                await _context.SaveChangesAsync();
            }

            return await OnGetAsync(Song.SongID, null);
        }
    }
}
