﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MP3Lib.Data;


namespace MP3Lib.Areas.Song.Pages {
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        public IndexModel(ApplicationDbContext context)
        {
            _context = context;
        }

        public PaginatedList<Data.Song> Song { get;set; }

        public async Task OnGetAsync(int? pageIndex) {
            int pageSize = 20;
            IQueryable<Data.Song> songIQ = _context.Songs.Select(s=>s);
            Song = await PaginatedList <Data.Song>.CreateAsync(songIQ, pageIndex ?? 1, pageSize);
        }
    }
}
