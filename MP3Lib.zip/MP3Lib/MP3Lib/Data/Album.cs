﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MP3Lib.Data {
    public class Album {
        [Key]
        public int AlbumId { get; set; }

        [Required]
        [StringLength(50)]
        [ConcurrencyCheck]
        public string Name { get; set; }

        [StringLength(450)]
        public string Information { get; set; }

        public int Year { get; set; }

        public virtual ICollection<AlbumSongs> Songs { get; set; }
    }

    public class AlbumSongs {
        public int AlbumId { get; set; }
        public int SongID { get; set; }
        public virtual Album Album { get; set; }
        public virtual Song Song { get; set; }
    }
}
